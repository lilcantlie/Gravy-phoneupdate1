# Gravy's iPhone (website simulasi iPhone 15 Pro Max · dark mode)

Website statis murni (tanpa build / tanpa framework). Tinggal upload semua isi folder ini ke GitHub.

## Struktur
```
index.html            kerangka layar (lock, passcode, status bar, dynamic island)
style.css             semua tampilan
app.js                semua logika + semua DATA (chat, foto, musik, dll.)
assets/
  wallpaper-lock.jpg  wallpaper lockscreen (bintang di langit malam)
  avatar.jpg          foto profil Instagram
  posts/post-1..3.jpg 3 postingan Instagram
  photos/2026-MM-N.jpg foto per bulan (Jan–Okt 2026)
  stories/*.jpg       gambar story (me-1..4, baby-1..3, maxton-1, evander-1, eiser-1)
  music/01..05.mp3    file lagu (opsional, lihat di bawah)
tools/make_placeholders.py  pembuat aset awal (boleh dihapus)
```

## Deploy ke GitHub Pages
1. Buat repo baru, upload semua file di atas (pertahankan struktur foldernya).
2. Settings → Pages → Source: *Deploy from a branch* → `main` / `(root)`.
3. Buka `https://USERNAME.github.io/NAMA-REPO/`.
(Bisa juga di Cloudflare Pages seperti contoh: pilih repo, build command kosong, output directory `/`.)

## Mengganti foto
Foto di `assets/` sekarang masih **placeholder**. Simpan foto dari Pinterest (kamu yang unduh),
lalu timpa file dengan **nama yang sama**:
- `assets/avatar.jpg` — foto profil IG
- `assets/posts/post-1.jpg`, `post-2.jpg`, `post-3.jpg`
- `assets/photos/2026-01-1.jpg` … `2026-10-3.jpg` (September 2 foto, Oktober 3 foto)
- `assets/wallpaper-lock.jpg` — ganti kalau mau wallpaper bintang yang lain

Mau menambah foto di bulan tertentu? Edit array `PHOTOS` di `app.js`.

## Musik
Letakkan file `01.mp3` … `05.mp3` di `assets/music/` (urutannya sesuai daftar `MUSIC` di `app.js`).
Kalau file belum ada, aplikasi otomatis menampilkan pemutar **Spotify embed** untuk lagu itu
(butuh internet; sebagian lagu hanya terputar preview kalau belum login Spotify).
Pastikan kamu punya hak memakai file lagu yang kamu upload.

## Mengubah isi
Semua teks ada di bagian `DATA` paling atas `app.js`:
passcode (`CFG.passcode`), bio/caption IG (`IG`), email (`MAILS`), catatan (`NOTES`),
riwayat telepon (`CALLS`), chat Telegram (`CHATS`), daftar lagu (`MUSIC`).
Tanggal & jam semua pesan dihitung relatif terhadap hari saat website dibuka.

## Catatan
- Passcode: **7777**. Di desktop, tombol di sisi kanan bingkai HP = kunci layar. `Esc` = kembali ke home.
- Cuaca Bandung mengambil data asli dari Open-Meteo (gratis, tanpa API key). Offline → tampil data contoh.
- Ikon app (Instagram, Telegram, Spotify) adalah gambar SVG sederhana buatan sendiri, bukan logo resmi.

## Fitur v2
- **Story Telegram**: lingkaran story di atas daftar chat. Tap kanan / geser kanan = lanjut, tap kiri / geser kiri = kembali,
  geser bawah = tutup, tahan = jeda. Habis → otomatis pindah ke story kontak berikutnya. Ada tombol like ❤️ dan kolom balas.
  Data di `STORIES` (app.js), durasi `STORY_MS`.
- **New Message** (ikon pensil di kanan atas Telegram) → daftar kontak (`TG_CONTACTS`), bisa dicari.
- **Chat baru**: Dito, Jason BEM FTI, Kevin HIMA TI, Zayn Cybersecurity, Andrew PPIC Staff + chat Baby baru.
  "Jumat"/"Sabtu" di chat dihitung dari Sabtu terbaru, jadi selalu benar kapan pun website dibuka.
- **Otomatis**: 1 menit setelah dibuka → banner chat dari Baby ("abang:(" lalu "kabarin akuu"); buka chat Baby →
  "Gravy is typing…" → balasan "I'll be home soon baby". 5 menit → telepon masuk dari Baby (Accept/Decline + subtitle).
  Decline → Missed Call di Recents. Atur waktunya di `TRIGGER`; tambahkan `?fast` di URL untuk mencoba cepat (2 dtk / 25 dtk).
- Foto avatar kontak opsional lewat `AVATARS` (kosong = inisial berwarna).
